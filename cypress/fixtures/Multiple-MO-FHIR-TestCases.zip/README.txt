The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 46 - 632475eb-a20a-43d6-baa7-f377ef8c5324 = DENOMPass RVCoagulation