The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - d07cf359-d46c-4adf-b2d4-e02a2f43b78e = DENEXCEPPass DEXANotPerformedPatienttRefused
Case # 2 - 4a7a2cf4-6073-47a0-9012-ea9b32e6e9db = NUMERFail NoDEXAOrderInMP
Case # 3 - e0997418-e22b-4aa9-805b-dde2c398787b = NUMERPass  DexaOrderInLast2YearsB4ADTOrder
Case # 4 - f3f9227e-50eb-4752-af8a-464072cc60c2 = NUMERPass  ADT9MonthsAfterStartofMPEdge
Case # 5 - ee053d16-adcb-4760-9305-6a553d789d9a = DENOMPass MedReqBoundsPriorToPCa