The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

bf8c5b10-807c-4a25-9f19-c47382501dee = SBTestSeriesP Passing Test Case
fc84f97d-29e5-45f1-8e9a-79b23f0900a4 = SBTestSeriesF Failing Test Case