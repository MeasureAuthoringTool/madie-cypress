The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

3c8b80a7-f8de-4b04-9323-c76503267385 = SBTestSeriesP Passing Test Case
c54054ad-0bf3-4de0-a45d-75f332ec3b1b = SBTestSeriesF Failing Test Case