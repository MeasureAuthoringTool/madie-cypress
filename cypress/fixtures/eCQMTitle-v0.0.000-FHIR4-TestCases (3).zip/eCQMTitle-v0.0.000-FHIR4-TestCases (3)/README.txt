The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

88bef60c-3bcc-4e8c-8c41-6da2b8566f13 = SBTestSeriesFb2 Failing Test Caseb2
d6250beb-184a-4aaa-ae71-c5d7911031cb = SBTestSeriesPb1 Passing Test Caseb1