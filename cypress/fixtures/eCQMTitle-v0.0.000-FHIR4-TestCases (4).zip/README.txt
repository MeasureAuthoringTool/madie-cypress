The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

da36f18f-95be-4f1c-8d8e-ca75ca53229f = SBTestSeriesP Passing Test Case
2f108922-4aa6-402f-a8a8-9098bce90f91 = SBTestSeriesF Failing Test Case