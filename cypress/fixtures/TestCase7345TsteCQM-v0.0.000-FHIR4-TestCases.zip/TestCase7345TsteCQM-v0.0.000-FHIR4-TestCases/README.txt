The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

4526f23a-db97-4e00-8b38-14679c06afd9 = ICFTCSeries Failing Test Case