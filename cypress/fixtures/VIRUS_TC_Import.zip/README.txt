The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

ccc408bf-fb64-474f-8e64-a83cd63a42d4 = SBTestSeriesPb1 Passing Test Caseb1
350a93a0-11da-4205-81b0-841e100ea031 = SBTestSeriesFb2 Failing Test Caseb2